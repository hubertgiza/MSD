public class Point {

    // TODO

    public void move() {
        // TODO
    }

    public void clicked() {
        // TODO
    }

    public void clear() {
        // TODO
    }
}